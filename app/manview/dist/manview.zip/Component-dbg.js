sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("manview.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);